create or replace PROCEDURE Z_3PL_MIKADO_SHIPMENTCONF_EMAIL (v_ref_number IN VARCHAR2, v_IsCommonEmail IN CHAR) AS
    -- SMTP connection variables
    v_mail_conn        UTL_SMTP.connection;
    v_boundary         VARCHAR2(100) := '----=*#abc1234321cba#*=';
    
    -- Email parameters
    v_sender           VARCHAR2(100) := 'donotreply-invoice@camso.co';
    v_recipient        VARCHAR2(100) := 'krishnakumar.rangasamy@tenthplanet.co';
    --v_recipient        VARCHAR2(100) := 'Manirathnam.thirumalaisamy@tenthplanet.co';
    v_subject          VARCHAR2(255) := 'Shipment Completion Notification';
    v_message          CLOB;
    v_mime_type        VARCHAR2(255) := 'text/html'; -- MIME type for HTML content
    v_boundary_end     VARCHAR2(255) := '--' || v_boundary || '--';
    
    v_so_documentno    VARCHAR2(100);
    v_prod_value       VARCHAR2(100);
    v_count            NUMBER;
    v_row_no           NUMBER:=1;
    
    -- Cursor to fetch shipment details
    CURSOR ref_numbers IS
        SELECT ref_number, Shipmentqty, M_Product_ID, sum(IMU_qty) AS IMU_QTY,error
        FROM mikado_tempdata 
        WHERE trunc(created) = trunc(sysdate)AND isimported = 'N' AND processed = 'Y' AND isinvalid = 'Y' AND error IS NOT NULL 
       -- AND isqtymismatch = 'Y' 
        AND ((v_ref_number = '0' AND v_IsCommonEmail = 'Y' AND send_email_to_common='N') OR
            (v_ref_number != '0' AND v_IsCommonEmail = 'N' AND send_email_to_user='N' AND ref_number = v_ref_number))
        GROUP BY ref_number, Shipmentqty, M_Product_ID,error
        ORDER BY ref_number;
    
BEGIN

    SELECT count(*) into v_count  FROM mikado_tempdata WHERE trunc(created) = trunc(sysdate) AND isimported = 'N' 
        AND processed = 'Y' AND isinvalid = 'Y' AND error IS NOT NULL 
       -- AND isqtymismatch = 'Y' 
        AND ((v_ref_number = '0' AND v_IsCommonEmail = 'Y' AND send_email_to_common='N') OR
            (v_ref_number != '0' AND v_IsCommonEmail = 'N' AND send_email_to_user='N' AND ref_number = v_ref_number));

 IF(v_count>0) THEN 
    IF v_IsCommonEmail='N' Then 
        BEGIN 
            select email into v_recipient from ad_user where ad_user_id = (    
                Select createdby from M_inout where Documentno = v_ref_number) and email is not null;
           EXCEPTION
                WHEN NO_DATA_FOUND THEN v_recipient:=null;
        END;
    END IF;   
    
    IF v_recipient is not null  THEN
    -- Initialize the email body as HTML format with CSS for styling
    v_message := '<html><head><style>';
    v_message := v_message || 'body {font-family: Arial, sans-serif; color: #333; background-color: #f4f4f4;}';
    v_message := v_message || 'h2 {color: #4CAF50; text-align: center; font-size: 24px;}';
    v_message := v_message || 'table {width: 70%; margin: 20px auto; border-collapse: collapse; background-color: #ffffff;}';
    v_message := v_message || 'th, td {padding: 15px; text-align: left; border: 1px solid #ddd;}';
    v_message := v_message || 'th {background-color: #007BFF; color: white; font-size: 16px;}';
    v_message := v_message || 'td {font-size: 14px;}';
    v_message := v_message || 'tr:nth-child(even) {background-color: #f9f9f9;}';
    v_message := v_message || 'tr:hover {background-color: #f1f1f1;}';
    v_message := v_message || '.footer {font-size: 12px; color: #888; text-align: center; margin-top: 20px;}';
    v_message := v_message || '</style></head><body>';

      v_message := v_message || '<h2 style="font-size: 18px; color: #333; text-align: center; padding: 10px; margin: 0;">Mikado Shipments not processed documents Notification</h2>';
    v_message := v_message || '<table><tr><th>S.No</th><th>Sales Order Number</th><th>Shipment Document Number</th>'
                               || '<th>Product</th><th>Shipment Qty in Document</th><th>Shipment Qty From Dachser</th>'
                               ||'<th>Comments</th></tr>';
    
    -- Loop through each record from the cursor
    FOR rec IN ref_numbers LOOP
        -- Fetch Sales Order Number using REF_CUSTOMER
        SELECT Documentno INTO v_so_documentno
        FROM C_Order
        WHERE C_Order_ID = (SELECT C_Order_ID FROM M_inout WHERE Documentno = rec.ref_number);
        
        -- Fetch Product Value using M_Product_ID
        SELECT Value INTO v_prod_value 
        FROM M_Product 
        WHERE M_Product_ID = rec.M_Product_ID;
        
        IF v_IsCommonEmail='N' Then 
            Update mikado_tempdata set send_email_to_user='Y' Where ref_number=rec.ref_number and M_Product_ID=rec.M_Product_ID;
        Else 
            Update mikado_tempdata set send_email_to_common='Y' Where ref_number=rec.ref_number and M_Product_ID=rec.M_Product_ID;
        END IF;
        
        -- Append the fetched details into the email message (HTML table rows)
        v_message := v_message || '<tr>';
        v_message := v_message || '<td>' || v_row_no || '</td>';
        v_message := v_message || '<td>' || v_so_documentno || '</td>';
        v_message := v_message || '<td>' || rec.ref_number || '</td>';
        v_message := v_message || '<td>' || v_prod_value || '</td>';
        v_message := v_message || '<td>' || rec.Shipmentqty || '</td>';
        v_message := v_message || '<td>' || rec.IMU_QTY || '</td>';
        v_message := v_message || '<td>' || rec.error || '</td>';
        v_message := v_message || '</tr>';
        
        v_row_no:=v_row_no+1;
    END LOOP;
    
    -- Close the table and body in the email
    v_message := v_message || '</table>';
    
    -- Footer section (optional, can be adjusted as needed)
    v_message := v_message || '<div class="footer">This is an automated notification. Please do not reply to this email.</div>';
    
    -- Close the body
    v_message := v_message || '</body></html>';

    -- Connect to the SMTP server
    v_mail_conn := UTL_SMTP.open_connection('smtp-us.csl.local', 25);

    -- Perform the initial SMTP handshake
    UTL_SMTP.helo(v_mail_conn, 'localhost');
    
    -- Specify the email headers (static headers)
    UTL_SMTP.mail(v_mail_conn, v_sender);
    UTL_SMTP.rcpt(v_mail_conn, v_recipient);
    UTL_SMTP.open_data(v_mail_conn);

    -- Write email headers and content
    UTL_SMTP.write_data(v_mail_conn, 'Subject: ' || v_subject || UTL_TCP.crlf);
    UTL_SMTP.write_data(v_mail_conn, 'MIME-Version: 1.0' || UTL_TCP.crlf);
    UTL_SMTP.write_data(v_mail_conn, 'Content-Type: multipart/alternative; boundary="' || v_boundary || '"' || UTL_TCP.crlf || UTL_TCP.crlf);
    UTL_SMTP.write_data(v_mail_conn, '--' || v_boundary || UTL_TCP.crlf);
    UTL_SMTP.write_data(v_mail_conn, 'Content-Type: ' || v_mime_type || '; charset="UTF-8"' || UTL_TCP.crlf || UTL_TCP.crlf);

    -- Send the dynamic body content (table)
    UTL_SMTP.write_data(v_mail_conn, v_message || UTL_TCP.crlf);
    
    -- Close the boundary for the email content
    UTL_SMTP.write_data(v_mail_conn, '--' || v_boundary || '--' || UTL_TCP.crlf);
    
    -- Close the email data section
    UTL_SMTP.close_data(v_mail_conn);

    -- Quit the SMTP connection
    UTL_SMTP.quit(v_mail_conn);
    END IF;
END IF;

EXCEPTION
    WHEN OTHERS THEN
        -- Error handling: Print the error message
        DBMS_OUTPUT.put_line('Error: ' || SQLERRM);
        -- Additional error handling if necessary
END;