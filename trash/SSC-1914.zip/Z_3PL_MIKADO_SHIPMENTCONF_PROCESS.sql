create or replace PROCEDURE Z_3PL_MIKADO_SHIPMENTCONF_PROCESS AS
    v_ref_number                VARCHAR2(100);
    v_minout_document_count     NUMBER := 0;
    v_user_id                   NUMBER := 100;
    v_doc_status                VARCHAR2(10);
    v_m_inout_id                NUMBER := 0;
    v_m_attributesetinstance_id NUMBER := 0;
    v_product_sum_inout         NUMBER := 0;
    v_product_sum_tempdata      NUMBER := 0;
    v_m_transaction_seq         NUMBER := 0;
    v_m_inoutlineconfirm_id     NUMBER := 0;
    v_m_inoutconfirm_id         NUMBER := 0;
    v_formatted_date            VARCHAR2(255);
    v_name                      VARCHAR2(255);
    v_isinvalid                 CHAR(1) := 'N';
    v_imu_qty                   NUMBER := 0;
    v_isqtymismatched           CHAR(1) := 'N';
    v_isqtymismatchedinFile     CHAR(1) := 'N';

    CURSOR c_ref_numbers IS
        SELECT ref_number
        FROM mikado_tempdata
        WHERE trunc(created) = trunc(sysdate) AND isimported = 'N' AND processed = 'N' AND isinvalid = 'N' AND error IS NULL
        GROUP BY ref_number;

BEGIN
    FOR rec IN c_ref_numbers LOOP
        SELECT COUNT(*)
        INTO v_minout_document_count
        FROM m_inout
        WHERE documentno = rec.ref_number;

        dbms_output.put_line('v_ref_number ' || rec.ref_number);
        v_isinvalid:='N';
        v_isqtymismatched :='N';

        IF v_minout_document_count = 0 THEN
            UPDATE mikado_tempdata
            SET processed = 'Y', error = 'The Document is not available in the Shipment', isinvalid = 'Y', updated = sysdate, updatedby = v_user_id
            WHERE ref_number = rec.ref_number; COMMIT;
            CONTINUE;
        END IF;

        SELECT docstatus, m_inout_id
        INTO v_doc_status, v_m_inout_id
        FROM m_inout
        WHERE documentno = rec.ref_number;

        IF v_doc_status = 'CO' THEN
            UPDATE mikado_tempdata
            SET processed = 'Y', error = 'The Document is already completed', isinvalid = 'Y', updated = sysdate, updatedby = v_user_id
            WHERE ref_number = rec.ref_number; COMMIT;
            CONTINUE;
        END IF;
        
        FOR rec2 IN (SELECT ref_number,article_number FROM mikado_tempdata WHERE ref_number = rec.ref_number and m_product_id is null) LOOP
            v_isinvalid := 'Y';
            UPDATE mikado_tempdata
            SET processed = 'Y', error = 'Product is not available in compiere', isinvalid = 'Y', updated = sysdate, updatedby = v_user_id
            WHERE ref_number = rec2.ref_number and article_number=rec2.article_number; 
            COMMIT;
        END LOOP;

        FOR rec1 IN (SELECT sum(qtyentered)as qtyentered,m_product_id FROM m_inoutline WHERE m_inout_id = v_m_inout_id 
        group by m_product_id order by m_product_id) LOOP
          BEGIN
            SELECT sum(imu_qty) INTO v_imu_qty
            FROM mikado_tempdata
            WHERE ref_number = rec.ref_number AND m_product_id = rec1.m_product_id group by m_product_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN v_imu_qty := 0;  
           END;

            IF v_imu_qty != rec1.qtyentered THEN
                v_isinvalid := 'Y'; 
                v_isqtymismatched  :='Y';
                v_isqtymismatchedinFile :='Y';
                UPDATE mikado_tempdata
                SET isinvalid = 'Y', error='Qty Mismatch', processed = 'Y', updated = sysdate, updatedby = v_user_id,
                isqtymismatch='Y', shipmentqty=rec1.qtyentered
                WHERE ref_number = rec.ref_number and m_product_id=rec1.m_product_id;
                COMMIT;
                --EXIT;
            END IF;
        END LOOP;

        IF v_isinvalid = 'N' THEN
            FOR rec1 IN (SELECT m_product_id, qtyentered, m_inoutline_id, c_orderline_id, m_locator_id FROM m_inoutline 
            WHERE m_inout_id = v_m_inout_id) LOOP
                BEGIN
                        SELECT m_attributesetinstance_id
                        INTO v_m_attributesetinstance_id
                        FROM m_storage
                        WHERE m_product_id = rec1.m_product_id
                        AND m_locator_id = rec1.m_locator_id
                        ORDER BY qtyonhand DESC
                        FETCH FIRST 1 ROWS ONLY;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN v_m_attributesetinstance_id := 0;
                    END;

                BEGIN
                     UPDATE m_storage
                    SET qtyonhand = qtyonhand - rec1.qtyentered, qtyreserved = qtyreserved - rec1.qtyentered, updated = sysdate, updatedby = v_user_id
                    WHERE m_product_id = rec1.m_product_id AND m_locator_id = rec1.m_locator_id AND m_attributesetinstance_id = v_m_attributesetinstance_id;

                    UPDATE m_inoutline
                    SET m_attributesetinstance_id = v_m_attributesetinstance_id, targetqty = rec1.qtyentered, processed = 'Y', 
                    updated = sysdate, updatedby = v_user_id
                    WHERE m_inoutline_id = rec1.m_inoutline_id;

                    SELECT currentnext
                    INTO v_m_transaction_seq
                    FROM ad_sequence
                    WHERE name = 'M_Transaction';

                    INSERT INTO m_transaction (
                        ad_client_id, ad_org_id, c_projectissue_id, created, createdby, isactive,
                        m_attributesetinstance_id, m_inoutline_id, m_inventoryline_id, m_locator_id,
                        m_movementline_id, m_product_id, m_productionline_id, m_transaction_id,
                        m_warehousetask_id, m_workordertransactionline_id, movementdate, movementqty,
                        movementtype, updated, updatedby
                    ) VALUES (
                        1000000, 1000000, NULL, sysdate, v_user_id, 'Y', v_m_attributesetinstance_id,
                        rec1.m_inoutline_id, NULL, rec1.m_locator_id, NULL, rec1.m_product_id, NULL,
                        v_m_transaction_seq, NULL, NULL, trunc(sysdate), -rec1.qtyentered, 'C-', sysdate, v_user_id
                    );

                    UPDATE ad_sequence
                    SET currentnext = currentnext + incrementno
                    WHERE name = 'M_Transaction';

                    SELECT m_inoutlineconfirm_id
                    INTO v_m_inoutlineconfirm_id
                    FROM m_inoutlineconfirm
                    WHERE m_inoutline_id = rec1.m_inoutline_id;

                    UPDATE m_inoutlineconfirm
                    SET confirmedqty = rec1.qtyentered, differenceqty = 0, targetqty = rec1.qtyentered, processed = 'Y', updated = sysdate, updatedby = v_user_id
                    WHERE m_inoutlineconfirm_id = v_m_inoutlineconfirm_id;

                    UPDATE c_orderline
                    SET datedelivered = sysdate, qtydelivered = qtydelivered + rec1.qtyentered, qtyreserved = qtyreserved - rec1.qtyentered, 
                    updated = sysdate, updatedby = v_user_id
                    WHERE c_orderline_id = rec1.c_orderline_id;

                    SELECT m_inoutconfirm_id
                    INTO v_m_inoutconfirm_id
                    FROM m_inoutconfirm
                    WHERE m_inout_id = v_m_inout_id;

                    SELECT name
                    INTO v_name
                    FROM ad_user
                    WHERE ad_user_id = v_user_id;

                    SELECT to_char(current_timestamp, 'YYYY-MM-DD HH24:MI:SS.FF')
                    INTO v_formatted_date
                    FROM dual;

                    UPDATE m_inoutconfirm
                    SET docstatus = 'CO', docaction = 'CL', isapproved = 'Y', processed = 'Y', description = v_name || ': Approved - ' || v_formatted_date
                    WHERE m_inoutconfirm_id = v_m_inoutconfirm_id;
                    Commit;
                END;
        END LOOP;
        END IF;

        IF v_isinvalid = 'N' THEN
            UPDATE m_inout
            SET movementdate = sysdate, dateacct = sysdate, docstatus = 'CO', docaction = 'RC', isapproved = 'Y', processed = 'Y', 
            updated = sysdate, updatedby = v_user_id
            WHERE m_inout_id = v_m_inout_id;

            UPDATE mikado_tempdata
            SET isimported = 'Y', processed = 'Y'
            WHERE ref_number = rec.ref_number;
            Commit;

            dbms_output.put_line('Shipment documents completed successfully');
        END IF;

    IF v_isinvalid='Y' Then 
--        FOR rec2 IN (SELECT m_product_id, qtyentered, m_inoutline_id, c_orderline_id, m_locator_id FROM m_inoutline WHERE m_inout_id = v_m_inout_id) LOOP
--            SELECT imu_qty INTO v_imu_qty
--            FROM mikado_tempdata
--            WHERE ref_number = rec.ref_number AND m_product_id = rec2.m_product_id;
--
--                    UPDATE m_inoutline
--                    SET movementqty = v_imu_qty, qtyentered = v_imu_qty,
--                    updated = sysdate, updatedby = v_user_id
--                    WHERE m_inoutline_id = rec2.m_inoutline_id;
--
--                    UPDATE m_inoutlineconfirm
--                    SET confirmedqty = v_imu_qty, targetqty = v_imu_qty, updated = sysdate, updatedby = v_user_id
--                    WHERE m_inoutline_id = rec2.m_inoutline_id;
--                    Commit;
--         END LOOP;
--
--        UPDATE m_inout
--        SET movementdate = sysdate, dateacct = sysdate,updated = sysdate, updatedby = v_user_id, 
--        nopackages=(SELECT sum(imu_qty) FROM mikado_tempdata WHERE ref_number = rec.ref_number)
--        WHERE m_inout_id = v_m_inout_id; 
        
        UPDATE mikado_tempdata SET isinvalid ='Y', processed = 'Y', error='This Document other lines having qty mismatch issue'
        WHERE ref_number = rec.ref_number and error is null and isqtymismatch='N';
        Commit;

     END IF;
     
     FOR rec2 IN (SELECT ref_number,article_number FROM mikado_tempdata WHERE ref_number = rec.ref_number and processed = 'Y') LOOP
            UPDATE mikado_tempdata
            SET processed = 'Y', error = 'Product is not available for the shipment', isinvalid = 'Y', updated = sysdate, updatedby = v_user_id
            WHERE ref_number = rec2.ref_number and article_number=rec2.article_number; 
            COMMIT;
     END LOOP;
     
      IF v_isqtymismatched='Y' THEN
          Z_3PL_MIKADO_SHIPMENTCONF_EMAIL(rec.ref_number,'N');
      END IF;
    END LOOP;
   
    IF v_isqtymismatchedinFile='Y' THEN
          Z_3PL_MIKADO_SHIPMENTCONF_EMAIL('0','Y');
    END IF;
    
END;