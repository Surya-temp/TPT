create or replace PROCEDURE Z_3PL_MIKADO_SHIPMENTCONF_IMPORT AS
    
    file_handle UTL_FILE.FILE_TYPE;
    v_line_content VARCHAR2(32767);
    v_line_number INTEGER := 0;
    v_refnumber CHAR(1) := 'N';
    pos INTEGER := 1;
    v_sysdate Date:=sysdate;
    v_is_last_day_of_Month CHAR(1) := 'N';
     
    v_shipment_date                VARCHAR2(255) :=NULL ;
    v_ref_number                   VARCHAR2(100) := NULL;
    v_consignee_number             VARCHAR2(255) := NULL;
    v_consignee_delivery_order_name_1 VARCHAR2(255) := NULL;
    v_consignee_delivery_order_name_2 VARCHAR2(255) := NULL;
    v_consignee_delivery_order_name_3 VARCHAR2(255) := NULL;
    v_consignee_street             VARCHAR2(255) := NULL;
    v_consignee_pcd                VARCHAR2(255) := NULL;
    v_consignee_city               VARCHAR2(255) := NULL;
    v_consignee_ncd                VARCHAR2(255) := NULL;
    v_withdrawal_type              VARCHAR2(255) := NULL;
    v_article_number               VARCHAR2(255) := NULL;
    v_article_name                 VARCHAR2(255) := NULL;
    v_article_name_2               VARCHAR2(255) := NULL;
    v_imu_qty                      NUMBER := 0;
    v_imu_quantity_unit            VARCHAR2(255) := NULL;
    v_user_id                      NUMBER :=100; --SuperUser
    v_insert_rows                  NUMBER :=0;
    v_filename                     VARCHAR2(500) := 'MIKADO_REPORT_00957_20250124_16164659 _1_UAT.csv';
    
BEGIN
    file_handle := UTL_FILE.FOPEN('FR_INVOICES', v_filename, 'R');
    LOOP
        v_line_number := v_line_number + 1;
        UTL_FILE.GET_LINE(file_handle, v_line_content);
        
        IF v_line_content LIKE '%Fin de la liste / End of list%' THEN
            EXIT;  
        END IF;

        IF v_line_content LIKE '%Ref. number%' THEN
            v_refnumber := 'Y';
            CONTINUE;
             --DBMS_OUTPUT.PUT_LINE('Line number : ' || v_line_number || ' Found "Ref. number" in line: ' || v_line_content);
        END IF;

        IF v_refnumber = 'Y' THEN
            pos := 1;
            v_line_content :=REPLACE(v_line_content, '''', '');  
            --DBMS_OUTPUT.PUT_LINE(v_line_content);
            
            v_shipment_date := REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1);
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_ref_number := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_number := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_delivery_order_name_1 := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_delivery_order_name_2 := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_delivery_order_name_3 := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_street := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_pcd := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_city := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_consignee_ncd := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_withdrawal_type := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_article_number := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_article_name := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_article_name_2 := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;
            
           -- DBMS_OUTPUT.PUT_LINE('Line no ' || v_line_number);
           -- DBMS_OUTPUT.PUT_LINE('v_line_content ' || v_line_content);
            v_imu_qty := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE TO_NUMBER(REPLACE(REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1), ',', '')/1000)
                END;
            pos := INSTR(v_line_content, ';', pos) + 1;

            v_imu_quantity_unit := 
                CASE 
                    WHEN REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1) = '' THEN NULL
                    ELSE REGEXP_SUBSTR(v_line_content, '[^;]+', pos, 1)
                END;
                
            Select case 
                    when trunc(sysdate)=last_day(sysdate) then 'Y'
                    Else 'N'
                    END into v_is_last_day_of_Month
            From dual;
            
            IF v_is_last_day_of_Month ='Y' Then
                v_sysdate := SYSDATE + 1;
            END IF;
            
            INSERT INTO MIKADO_TEMPDATA (AD_CLIENT_ID, AD_ORG_ID, ARTICLE_NAME, ARTICLE_NAME_2, ARTICLE_NUMBER, CONSIGNEE_CITY, 
            CONSIGNEE_DELIVERY_ORDER_NAME_1, CONSIGNEE_DELIVERY_ORDER_NAME_2, CONSIGNEE_DELIVERY_ORDER_NAME_3, CONSIGNEE_NCD, 
            CONSIGNEE_NUMBER, CONSIGNEE_PCD, CONSIGNEE_STREET, CREATED, CREATEDBY, ERROR ,FILENAME, IMU_QTY, IMU_QUANTITY_UNIT, ISIMPORTED,
            PROCESSING, PROCESSED, REF_NUMBER, SHIPMENT_DATE, UPDATED, UPDATEDBY, WITHDRAWAL_TYPE)
            VALUES (1000000, 1000000, v_article_name, v_article_name_2, v_article_number, v_consignee_city, 
            v_consignee_delivery_order_name_1, v_consignee_delivery_order_name_2, v_consignee_delivery_order_name_3, v_consignee_ncd,
            v_consignee_number, v_consignee_pcd, v_consignee_street, v_sysdate, v_user_id, null,v_filename, v_imu_qty, v_imu_quantity_unit,
            'N','N', 'N', v_ref_number, v_shipment_date, v_sysdate, v_user_id,v_withdrawal_type);
            v_insert_rows:=v_insert_rows+1;
            Commit;
            
            Update MIKADO_TEMPDATA set m_product_id=(Select M_product_id from m_product where value=v_article_number and ad_org_id=1000000)
            where ARTICLE_NUMBER=v_article_number ;
            Commit;
            
        END IF;
    END LOOP;
    DBMS_OUTPUT.PUT_LINE('Records Inserted Successfully. Total Rows : '|| v_insert_rows);
    Z_3PL_MIKADO_SHIPMENTCONF_PROCESS();

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        UTL_FILE.FCLOSE(file_handle);
    WHEN OTHERS THEN
        UTL_FILE.FCLOSE(file_handle);
        RAISE;
END;