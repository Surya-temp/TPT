create or replace PROCEDURE z_fr_mr_import AS

   file_handle        UTL_FILE.FILE_TYPE;
    v_line_content     VARCHAR2(32767);
    v_line_number      INTEGER := 0;
    pos                INTEGER := 1;
    v_delivery         VARCHAR2(50);
    v_es               VARCHAR2(50);
    v_div              VARCHAR2(50);
    v_article          VARCHAR2(100);
    v_deliveryqty      NUMBER;
    v_uq               VARCHAR2(50);
    v_doc_sale         VARCHAR2(50);
    v_job              VARCHAR2(50);
    v_orderqty         NUMBER;
    v_uq1              VARCHAR2(50);
    v_ref_customer     VARCHAR2(100);
    v_job1             VARCHAR2(50);
    v_insert_rows      NUMBER := 0;
    --default values
    v_ad_org_id        NUMBER := 1000000; -- France
    v_ad_client_id     NUMBER := 1000000; 
    v_user_id          NUMBER := 100; -- SuperUser
    v_filename         VARCHAR2(300) := 'PSN extraction from SAP - 2.csv';

BEGIN
    file_handle := UTL_FILE.FOPEN('FR_INVOICES', v_filename, 'R');
    LOOP
        v_line_number := v_line_number + 1;
        UTL_FILE.GET_LINE(file_handle, v_line_content);

        IF v_line_content LIKE '%Réf. client%' THEN
            CONTINUE;
        END IF;

        pos := 1;
        v_delivery := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_es := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_div := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_article := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_deliveryqty := TO_NUMBER(REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1));
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_uq := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_doc_sale := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_job := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_orderqty := TO_NUMBER(REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1));
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_uq1 := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_ref_customer := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        v_job1 := REGEXP_SUBSTR(v_line_content, '[^,]+', pos, 1);
        pos := INSTR(v_line_content, ',', pos) + 1;

        INSERT INTO z_fr_mr_tempdata (
            ad_client_id, ad_org_id, article, created, createdby, delivery, deliveryqty, div, doc_sale, 
            es, job, job1, orderqty, ref_customer, uq, uq1, updated, updatedby
        ) VALUES (
            v_ad_client_id, v_ad_org_id, v_article, SYSDATE, v_user_id, v_delivery, v_deliveryqty, v_div, v_doc_sale, 
            v_es, v_job, v_job1, v_orderqty, v_ref_customer, v_uq, v_uq1, SYSDATE, v_user_id
        );
        v_insert_rows := v_insert_rows + 1;
        COMMIT;

        UPDATE z_fr_mr_tempdata 
        SET m_product_id = (
            SELECT m_product_id FROM m_product 
            WHERE value = v_article AND ad_org_id = v_ad_org_id
        )
        WHERE article = v_article;
        COMMIT;

    END LOOP;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        IF v_insert_rows>0 THEN 
            Z_FR_MR_PROCESS();
        END IF;
        UTL_FILE.FCLOSE(file_handle);
    WHEN OTHERS THEN
        UTL_FILE.FCLOSE(file_handle);
        RAISE;
END;
