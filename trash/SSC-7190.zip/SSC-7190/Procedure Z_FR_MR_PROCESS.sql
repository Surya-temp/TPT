CREATE OR REPLACE PROCEDURE Z_FR_MR_PROCESS AS

    v_ref_customer           VARCHAR(100);
    v_minout_document_count  NUMBER;
    v_isinvalid              CHAR(1) := 'N';
    v_doc_status             VARCHAR2(10);
    v_c_order_id             NUMBER := 0;
    v_minout_header_created  CHAR(1) := 'N';
    v_qtyentered             NUMBER := 0;
    v_freightamt             NUMBER := 0;
    v_freightcostrule        CHAR(1);
    v_c_bpartner_id          NUMBER := 0;
    v_c_bpartner_location_id NUMBER := 0;
    v_documentno_seq         NUMBER := 0;
    v_m_inout_seq            NUMBER := 0;
    v_m_warehouse_id         NUMBER := 0;
    v_deliveryviarule        CHAR(1);
    v_deliveryrule           CHAR(1);
    v_line_no                NUMBER := 0;
    v_m_inoutline_seq        NUMBER;
    v_m_locator_id           NUMBER;
    v_qtyentered_val         NUMBER;
    v_c_orderline_id         NUMBER;
    v_c_uom_id               NUMBER;
    v_lines_processed        NUMBER := 0;
    v_minout_qty             NUMBER;
    v_temptable_lines        NUMBER;
    --default values
    v_user_id                NUMBER := 100; -- SuperUser
    v_c_doctype_id           NUMBER := 1000046;
    v_ad_org_id              NUMBER := 1000000; -- France
    v_ad_client_id           NUMBER := 1000000; 


    CURSOR Ref_customer IS 
        SELECT REF_CUSTOMER INTO v_ref_customer 
        FROM Z_FR_MR_TEMPDATA 
        WHERE TRUNC(created) = TRUNC(sysdate) AND isimported = 'N' AND processed = 'N' AND isinvalid = 'N' AND error IS NULL
        GROUP BY REF_CUSTOMER ORDER BY REF_CUSTOMER;

BEGIN 

    FOR rec IN Ref_customer LOOP
        SELECT COUNT(*) INTO v_minout_document_count
        FROM C_order
        WHERE documentno = rec.Ref_customer;
        
        --DBMS_OUTPUT.PUT_LINE('v_ref_number ' || rec.Ref_customer);
        v_isinvalid := 'N';
        v_line_no := 10;
        v_lines_Processed :=0;
        
        --Validation The Document is not available in the Purchase Order
        IF v_minout_document_count = 0 THEN
            UPDATE Z_FR_MR_TEMPDATA
            SET processed = 'Y', error = 'The Document is not available in the Purchase Order', isinvalid = 'Y', 
                updated = SYSDATE, updatedby = v_user_id
            WHERE Ref_customer = rec.Ref_customer; 
            COMMIT;
            CONTINUE;
        END IF;
        
        SELECT docstatus, C_order_id INTO v_doc_status, v_c_order_id
        FROM C_Order
        WHERE documentno = rec.Ref_customer;
        --Validation The Document is already completed
        IF v_doc_status != 'CO' THEN
            UPDATE Z_FR_MR_TEMPDATA
            SET processed = 'Y', error = 'The Document is not completed', isinvalid = 'Y', updated = SYSDATE, updatedby = v_user_id
            WHERE Ref_customer = rec.Ref_customer; 
            COMMIT;
            CONTINUE;
        END IF;
        
        --Validation Delivery qty is high and PO qunatity is low
        FOR rec1 IN (SELECT SUM(deliveryqty) as deliveryqty, m_product_id FROM Z_FR_MR_TEMPDATA
                WHERE Ref_customer = rec.Ref_customer GROUP BY m_product_id ORDER BY m_product_id) LOOP
            BEGIN
                SELECT SUM(qtyentered) into v_qtyentered_val
                     FROM C_orderLine 
                     WHERE C_order_id = v_c_order_id and m_product_id=rec1.m_product_id
                     GROUP BY m_product_id;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN v_qtyentered_val := 0;  
            END;

            IF rec1.deliveryqty > v_qtyentered_val THEN
                v_isinvalid := 'Y';
                UPDATE Z_FR_MR_TEMPDATA
                SET isinvalid = 'Y', error = 'Delivery qty is high and PO qunatity is low', processed = 'Y', 
                updated = SYSDATE, updatedby = v_user_id WHERE Ref_customer = rec.Ref_customer;
                COMMIT;
                EXIT;
            END IF;
        END LOOP;
        
        --Validation Purchese order qunatity is low
        SELECT COUNT(*) INTO v_temptable_lines FROM Z_FR_MR_TEMPDATA WHERE Ref_customer = rec.Ref_customer;
        
        IF v_isinvalid = 'N' THEN
            FOR rec1 IN (SELECT M_Product_id, deliveryqty FROM Z_FR_MR_TEMPDATA WHERE REF_CUSTOMER = rec.REF_CUSTOMER
                         ORDER BY M_Product_id ASC, deliveryqty DESC) LOOP
                
                SELECT qtyentered, c_orderline_id, C_UOM_ID
                INTO v_qtyentered, v_c_orderline_id, v_C_UOM_ID
                FROM C_orderLine 
                WHERE C_order_id = v_c_order_id AND M_Product_id = rec1.M_Product_id AND isactive = 'Y'
                ORDER BY M_product_id ASC, QtyEntered DESC FETCH FIRST 1 ROW ONLY;
                
                IF (v_qtyentered >= rec1.deliveryqty) THEN 
                    v_lines_Processed := v_lines_Processed + 1;
                END IF;
            END LOOP;
            
            IF v_lines_Processed != v_temptable_lines THEN
                v_isinvalid := 'Y';
                UPDATE Z_FR_MR_TEMPDATA SET processed = 'Y', error = 'Purchese order qunatity is low. Check the file', 
                isinvalid = 'Y', updated = SYSDATE, updatedby = v_user_id WHERE Ref_customer = rec.Ref_customer; 
                COMMIT;
                CONTINUE;
            END IF;
            
        END IF;
        
        --Document header processing started
        IF v_isinvalid = 'N' THEN
            SELECT C_BPartner_ID, M_Warehouse_ID, C_BPartner_Location_ID, DeliveryRule, DeliveryViaRule, 
                   FreightAmt, FreightCostRule
            INTO v_C_BPartner_ID, v_M_Warehouse_ID, v_C_BPartner_Location_ID, v_DeliveryRule, v_DeliveryViaRule,
                 v_FreightAmt, v_FreightCostRule
            FROM C_Order 
            WHERE Documentno = rec.Ref_customer;
                
            SELECT currentnext INTO v_documentno_seq FROM ad_sequence WHERE ad_sequence_id = 1000028; 
            SELECT currentnext INTO v_m_inout_seq FROM ad_sequence WHERE ad_sequence_id = 256; 
                
            INSERT INTO M_InOut (AD_Client_ID, AD_Org_ID, C_BPartner_ID, C_BPartner_Location_ID, C_DocType_ID, ChargeAmt,
                                 CreateConfirm, CreateFrom, CreatePackage, Created, CreatedBy, DateAcct, DeliveryRule, 
                                 DeliveryViaRule, DocAction, DocStatus, DocumentNo, FreightAmt, FreightCostRule, IsActive, 
                                 IsApproved, IsInDispute, IsInTransit, IsPrinted, IsReturnTrx, IsSOTrx, M_InOut_ID, 
                                 M_Warehouse_ID, MovementDate, MovementType, NoPackages, Posted, PriorityRule, Processed, 
                                 Processing, SendEMail, Updated, UpdatedBy, Volume, Weight, C_order_id) 
                                 
            VALUES (v_ad_client_id, v_ad_org_id, v_C_BPartner_ID, v_C_BPartner_Location_ID, v_c_doctype_id, 0, 'N', 'N', 'N', 
                    SYSDATE, v_user_id, SYSDATE, v_DeliveryRule, v_DeliveryViaRule, 'CO', 'DR', v_documentno_seq, 
                    v_FreightAmt, v_FreightCostRule, 'Y', 'N', 'N', 'N', 'N', 'N', 'N', v_m_inout_seq, v_M_Warehouse_ID, 
                    SYSDATE, 'V+', 0, 'N', '5', 'N', 'N', 'N', SYSDATE, v_user_id, 0, 0, v_c_order_id);

            UPDATE ad_sequence SET currentnext = currentnext + incrementno WHERE ad_sequence_id = 256;
            UPDATE ad_sequence SET currentnext = currentnext + incrementno WHERE ad_sequence_id = 1000028;
            COMMIT;
            --DBMS_OUTPUT.PUT_LINE('PO ' || rec.Ref_customer||' - MR Documetno ' || v_documentno_seq);
        END IF;
                
        --Document Line processing started
        IF v_isinvalid = 'N' AND v_lines_Processed = v_temptable_lines THEN
            FOR rec1 IN (SELECT M_Product_id, deliveryqty FROM Z_FR_MR_TEMPDATA WHERE REF_CUSTOMER = rec.REF_CUSTOMER
                         ORDER BY M_Product_id ASC, deliveryqty DESC) LOOP
                
                SELECT qtyentered, c_orderline_id, C_UOM_ID
                INTO v_qtyentered, v_c_orderline_id, v_C_UOM_ID
                FROM C_orderLine 
                WHERE C_order_id = v_c_order_id AND M_Product_id = rec1.M_Product_id AND isactive = 'Y'
                ORDER BY M_product_id ASC, QtyEntered DESC FETCH FIRST 1 ROW ONLY;
                
                IF (v_qtyentered >= rec1.deliveryqty) THEN 
                    --For this update to avoid retreive same line multiple times
                    UPDATE C_orderLine SET isactive = 'N' WHERE C_orderline_id = v_c_orderline_id AND isactive = 'Y';
                    COMMIT;
                    
                    SELECT currentnext INTO v_m_inoutLine_seq FROM ad_sequence WHERE ad_sequence_id = 257; 
                    BEGIN
                        SELECT m_locator_id INTO v_m_locator_id FROM m_locator 
                        WHERE m_warehouse_id = v_M_Warehouse_ID AND isactive = 'Y' FETCH FIRST 1 ROW ONLY;
                    EXCEPTION
                        WHEN NO_DATA_FOUND THEN v_m_locator_id := 5000054;
                    END;
                    
                    INSERT INTO M_InOutLine (AD_Client_ID, AD_Org_ID, C_OrderLine_ID, C_UOM_ID, ConfirmedQty, Created, 
                                             CreatedBy, IsActive, IsDescription, IsInvoiced, Line, M_InOutLine_ID, M_InOut_ID, 
                                             M_Locator_ID, M_Product_ID, MovementQty, PickedQty, Processed, QtyEntered, ScrappedQty, 
                                             TargetQty, Updated, UpdatedBy) 
                    VALUES (v_ad_client_id, v_ad_org_id, v_c_orderline_id, v_C_UOM_ID, 0, SYSDATE, v_user_id, 'Y', 'N', 'N', 
                            v_line_no, v_m_inoutLine_seq, v_m_inout_seq, v_m_locator_id, rec1.M_Product_ID, 
                            rec1.deliveryqty, 0, 'N', rec1.deliveryqty, 0, 0, SYSDATE, v_user_id);
                    
                    UPDATE ad_sequence SET currentnext = currentnext + incrementno WHERE ad_sequence_id = 257;
                    COMMIT;
                    v_line_no := v_line_no + 10;
                END IF;
                
            END LOOP;
            
            DBMS_OUTPUT.PUT_LINE('PO ' || rec.Ref_customer||' - MR Documetno ' || v_documentno_seq ||'- Lines created '||v_lines_Processed);
            
            SELECT SUM(MovementQty) INTO v_minout_qty FROM M_inoutline WHERE m_inout_id = v_m_inout_seq;
            
            UPDATE C_orderLine SET isactive = 'Y' WHERE C_order_ID = v_c_order_id AND isactive = 'N';
            UPDATE M_Inout SET nopackages = v_minout_qty, updated = SYSDATE, updatedby = v_user_id 
                WHERE m_inout_id = v_m_inout_seq;
            UPDATE Z_FR_MR_TEMPDATA SET isimported = 'Y', processed = 'Y', MR_DOCUMENTNO = v_documentno_seq
                WHERE REF_CUSTOMER = rec.REF_CUSTOMER AND isimported = 'N' AND processed = 'N' AND isinvalid = 'N' AND error IS NULL;
            COMMIT;
        END IF;
        
    END LOOP;

END;

